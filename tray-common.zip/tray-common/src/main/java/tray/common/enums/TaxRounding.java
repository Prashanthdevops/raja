package tray.common.enums;

public enum TaxRounding {

}
