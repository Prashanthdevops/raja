package tray.common.enums;

public enum TaxInclusiveType {
	NET,
	GROSS
}
