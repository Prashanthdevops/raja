package tray.common.util;

import tray.common.Discount;
import tray.common.pojo.OrderItem;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

public class DiscountComputation {

    public static void computeDiscounts(List<OrderItem> orderItems, String discountType, Double discountValue, Double checkTotal) {
        Double percent, totalDiscAmount, itemPriceAfterDiscount;
        // calculate percentage for flat discount, totalDiscAmount for percentage
        if (discountType == "FLAT") {
            percent = discountValue / checkTotal;
            totalDiscAmount = discountValue;
        } else {
            percent = discountValue;
            totalDiscAmount = checkTotal * (percent / 100);
        }
        Double remainingDiscAmount = totalDiscAmount;
        for (int i = 0; i < orderItems.size(); i++) {
            OrderItem item = orderItems.get(i);
            if (i == orderItems.size() - 1) {
                itemPriceAfterDiscount = item.getActualItemPrice() - remainingDiscAmount;
                item.setItemPrice(itemPriceAfterDiscount);
            } else {
                Double discountedPrice = item.getActualItemPrice() * (percent / 100);
                itemPriceAfterDiscount = item.getActualItemPrice() - discountedPrice;
                item.setItemPrice(itemPriceAfterDiscount.doubleValue());
                remainingDiscAmount = remainingDiscAmount - discountedPrice;
            }
        }


    }


}
