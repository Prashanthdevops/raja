package tray.common.enums;
/**
 * TaxRateType enum used for taxation
 * 
 * @author Saikrishna Yelisetty
 * @version 1.0
 */
public enum TaxRateType {
	PERCENTAGE,
	FIXED
}
