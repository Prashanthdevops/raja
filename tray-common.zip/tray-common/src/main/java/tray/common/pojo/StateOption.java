package tray.common.pojo;

import com.google.gson.annotations.SerializedName;

import java.io.Serializable;

public class StateOption implements Serializable {

    private int id;
    @SerializedName("skip")
    private boolean isSkip;
    @SerializedName("auto")
    private boolean isAuto;
    private String timeout;
}
