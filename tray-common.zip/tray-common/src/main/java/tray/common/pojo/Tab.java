package tray.common.pojo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Tab implements Serializable {
    private List<Order> orders;
    private String id;
    private double totalTax;
    private HashMap<String, Taxation> taxes;
    private HashMap<String, Category> categories;
    private Service service;

    public List<Order> getOrders() {
        return orders;
    }

    public void setOrders(List<Order> orders) {
        this.orders = orders;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public double getTotalTax() {
        return totalTax;
    }

    public void setTotalTax(double totalTax) {
        this.totalTax = totalTax;
    }

    public Taxation getTax(String id) {
        return taxes.get(id);
    }

    public List<Taxation> getTaxes() {
        return new ArrayList<Taxation>(taxes.values());
    }

    public void setTaxes(List<Taxation> taxes) {
        this.taxes = new HashMap();

        if (taxes != null) {
            for (Taxation tax : taxes) {
                this.taxes.put(tax.getId() + "", tax);
            }
        }
    }

    public Category getCategory(String id) {
        return categories.get(id);
    }

    public List<Category> getCategories() {
        return new ArrayList<Category>(categories.values());
    }

    public void setCategories(List<Category> categories) {
        this.categories = new HashMap();

        if (categories!=null) {
            for (Category category : categories) {
                this.categories.put(category.getId() + "", category);
            }
        }
    }

    public Service getService() {
        return service;
    }

    public void setService(Service service) {
        this.service = service;
    }

}

