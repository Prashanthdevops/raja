package tray.common;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import tray.common.util.TaxComputations;

public class TaxComputationsTest {

	/*@Test
	public void calculateTax()
	{

		Tax tax = new Tax();
		TaxComputations.calculateTax(tax);
		assertEquals(tax.getTaxAmount(), 10);
		assertEquals(tax.getAmountAfterTax(), 40);
	}
	
	@Test
	public void calculateTaxInclusive()
	{
		Tax tax = new Tax();
		TaxComputations.calculateTax(tax);
		assertEquals(tax.getTaxAmount(), 10);
		assertEquals(tax.getAmountAfterTax(), 40);
	}*/
}
