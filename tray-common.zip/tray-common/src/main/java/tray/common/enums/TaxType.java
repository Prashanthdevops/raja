package tray.common.enums;
/**
 * TaxType enum used for taxation
 * 
 * @author Saikrishna Yelisetty
 * @version 1.0
 */
public enum TaxType { TAX, ORDERTOTAL, ORDERQUANTITY}
