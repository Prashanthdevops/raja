package tray.common.pojo;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Taxes pojo object used for taxation
 *
 * @author Saikrishna Yelisetty
 * @version 1.0
 */
public class Taxation implements Serializable {
    private long id;
    private String name;
    private String venueId;
    private String type;
    private double orderTotal;
    private int itemQuantity;
    private String roundingOption;
    private String taxRateType;
    private double tax;
    private String status;
    private String taxTableJson;
    private boolean inclusiveType;
    private ArrayList<String> product;
    private ArrayList<String> service;
    private ArrayList<String> category;

    private double taxAmount;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVenueId() {
        return venueId;
    }

    public void setVenueId(String venueId) {
        this.venueId = venueId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getOrderTotal() {
        return orderTotal;
    }

    public void setOrderTotal(double orderTotal) {
        this.orderTotal = orderTotal;
    }

    public int getItemQuantity() {
        return itemQuantity;
    }

    public void setItemQuantity(int itemQuantity) {
        this.itemQuantity = itemQuantity;
    }

    public String getRoundingOption() {
        return roundingOption;
    }

    public void setRoundingOption(String roundingOption) {
        this.roundingOption = roundingOption;
    }

    public String getTaxRateType() {
        return taxRateType;
    }

    public void setTaxRateType(String taxRateType) {
        this.taxRateType = taxRateType;
    }

    public double getTax() {
        return tax;
    }

    public void setTax(double tax) {
        this.tax = tax;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTaxTableJson() {
        return taxTableJson;
    }

    public void setTaxTableJson(String taxTableJson) {
        this.taxTableJson = taxTableJson;
    }

    public boolean isInclusiveType() {
        return inclusiveType;
    }

    public void setInclusiveType(boolean inclusiveType) {
        this.inclusiveType = inclusiveType;
    }

    public ArrayList<String> getProduct() {
        return product;
    }

    public void setProduct(ArrayList<String> product) {
        this.product = product;
    }

    public ArrayList<String> getService() {
        return service;
    }

    public void setService(ArrayList<String> service) {
        this.service = service;
    }

    public ArrayList<String> getCategory() {
        return category;
    }

    public void setCategory(ArrayList<String> category) {
        this.category = category;
    }

    public double getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(double taxAmount) {
        this.taxAmount = taxAmount;
    }
}
