package tray.common;

import java.math.BigDecimal;

/**
 * Discount object to capture discount information
 * @author veeramaddipati
 *
 */
public class Discount {
	
	/**
	 * Actual amount
	 */
	private BigDecimal amount = null;
	
	/**
	 * % of discount to be applied
	 */
	private BigDecimal percentage = null;
	
	/**
	 * flat discount amount to be applied
	 */
	private BigDecimal discountAmount = null;
	
	/**
	 * amount after discount applied
	 */
	private BigDecimal amountAfterDiscount = null;

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getPercentage() {
		return percentage;
	}

	/**
	 * 
	 * @param percentage 
	 */
	public void setPercentage(BigDecimal percentage) {
		this.percentage = percentage;
	}

	/**
	 * 
	 * @return discount amount
	 */
	public BigDecimal getDiscountAmount() {
		return discountAmount;
	}

	/**
	 * 
	 * @param discountAmount - flat discount amount to be applied
	 */
	public void setDiscountAmount(BigDecimal discountAmount) {
		this.discountAmount = discountAmount;
	}

	/**
	 * 
	 * @return amount after discount applied
	 */
	public BigDecimal getAmountAfterDiscount() {
		return amountAfterDiscount;
	}

	/**
	 * 
	 * @param amountAfterDiscount
	 */
	public void setAmountAfterDiscount(BigDecimal amountAfterDiscount) {
		this.amountAfterDiscount = amountAfterDiscount;
	}

}
