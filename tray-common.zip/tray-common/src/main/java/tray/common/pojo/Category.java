package tray.common.pojo;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Category object
 * 
 * @author Saikrishna Yelisetty
 * @version 1.0
 */
public class Category implements Serializable {
	
	private Long id;
	private String name;
	private String categoryBarcode;
	private ArrayList<StateOption> stateOptions;

	public Category(List<Taxation> taxes, Long id) {
		super();
		this.id = id;
	}

	public Category(List<Taxation> taxes, Long id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCategoryBarcode() {
		return categoryBarcode;
	}

	public void setCategoryBarcode(String categoryBarcode) {
		this.categoryBarcode = categoryBarcode;
	}

	public ArrayList<StateOption> getStateOptions() {
		return stateOptions;
	}
}
