package tray.common.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import tray.common.pojo.Order;
import tray.common.pojo.OrderItem;
import tray.common.pojo.Tab;
import tray.common.pojo.Taxation;

/**
 * @author Ankur Maity
 */
public class TaxComputations {

    /**
     * Calculate and return tax for entire tab
     *
     * @param tab Tab object
     * @return
     */
    public static Tab calculateTax(Tab tab) {
        List<OrderItem> itemsList = new ArrayList<>();

        for (Order order : tab.getOrders()) {
            itemsList.addAll(order.getOrderItems());
        }

        identifyTax(tab, itemsList);
        tab.setTotalTax(aggregateTax(tab.getTaxes()));

        return tab;
    }

    /**
     * Identify tax type and calculate tax according to tax type
     *
     * @param tab
     * @param itemsList
     */
    private static void identifyTax(Tab tab, List<OrderItem> itemsList) {
        List<Taxation> inclusiveTaxations = new ArrayList<>();
        List<Taxation> exclusiveTaxations = new ArrayList<>();
        for (Taxation tax : tab.getTaxes()) {
            try {
                if (tax.isInclusiveType()) {
                    inclusiveTaxations.add(tax);
                } else {
                    exclusiveTaxations.add(tax);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Calculate tax for inclusive tax
        for (Taxation tax : inclusiveTaxations) {
            try {
                if (tax.getType().equalsIgnoreCase("ITEMTAX")) {
                    itemTax(tax, itemsList, tab.getService().getId());
                } else {
                    orderLevelTax(tax, itemsList, tab.getService().getId());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Discrepency adjustment after inclusive tax
        for (OrderItem orderItem : itemsList) {
            try {
                if (!orderItem.isDiscount()) {
                    BigDecimal discrepency = BigDecimal.ZERO;
                    if (orderItem.isTaxInclusive()) {
                        BigDecimal calculatedAmount = new BigDecimal(orderItem.getTaxableAmount() + "").add(new BigDecimal(orderItem.getTaxAmount() + ""));
                        BigDecimal actualAmount = new BigDecimal(orderItem.getActualItemPrice() + "").multiply(new BigDecimal(orderItem.getQuantity()));
                        discrepency = actualAmount.subtract(calculatedAmount);
                    }

                    orderItem.setTaxAmount((new BigDecimal(orderItem.getTaxAmount()+"").add(discrepency)).doubleValue());

                    if (discrepency.compareTo(BigDecimal.ZERO) != 0) {
                        for (Taxation tax : inclusiveTaxations) {
                            try {
                                if (tax.getTaxRateType().equalsIgnoreCase("PERCENTAGE")
                                        && tax.getTaxAmount() >= 0
                                        && (new BigDecimal(tax.getTaxAmount()).add(discrepency)).doubleValue() > 0
                                        && discrepency.compareTo(BigDecimal.ZERO) != 0) {
                                    tax.setTaxAmount((new BigDecimal(tax.getTaxAmount()).add(discrepency)).doubleValue());
                                    break;
                                }
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        //  Calculate tax for exclusive tax
        for (Taxation tax : exclusiveTaxations) {
            try {
                if (tax.getType().equalsIgnoreCase("ITEMTAX")) {
                    itemTax(tax, itemsList, tab.getService().getId());
                } else {
                    orderLevelTax(tax, itemsList, tab.getService().getId());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * Calculate ITEM TAX
     *
     * @param tax
     * @param itemsList
     * @param serviceID
     */
    private static void itemTax(Taxation tax, List<OrderItem> itemsList, long serviceID) {
        for (OrderItem item : itemsList) {
            if (isItemEligible(tax, item, serviceID)) {
                double taxAmount = applyTax(tax, item.getTaxableAmount(), item.getQuantity(), false);
                item.setTaxAmount(item.getTaxAmount() + taxAmount);
            }
        }
    }

    /**
     * Calculate order level tax (Item Quantity / Order Total)
     *
     * @param tax
     * @param itemsList
     * @param serviceID
     */
    private static void orderLevelTax(Taxation tax, List<OrderItem> itemsList, long serviceID) {
        ArrayList<OrderItem> eligibleItemList = new ArrayList();
        double amount = 0;
        int quantity = 0;

        for (OrderItem item : itemsList) {
            if (isItemEligible(tax, item, serviceID)) {
                eligibleItemList.add(item);
                amount += item.getTaxableAmount();
                quantity += item.getQuantity();
            }
        }

        if (!eligibleItemList.isEmpty()) {
            switch (tax.getType().toUpperCase()) {
                case "ITEMQUANTITY":
                    if (quantity >= tax.getItemQuantity()) {
                        applyTax(tax, amount, quantity, true);
                    }
                    break;
                case "ORDERTOTAL":
                    if (amount >= tax.getOrderTotal()) {
                        applyTax(tax, amount, quantity, true);
                    }
                    break;
            }
        }
    }

    /**
     * Check if an item is eligible for a tax
     *
     * @param tax
     * @param item
     * @param service
     * @return
     */
    private static boolean isItemEligible(Taxation tax, OrderItem item, long service) {
        return isItemEligible(tax, service, item.getCategoryId(), item.getItemId());
    }

    /**
     * Check if an item is eligible for a tax
     *
     * @param tax
     * @param service
     * @param categoryId
     * @param itemId
     * @return
     */
    private static boolean isItemEligible(Taxation tax, long service, long categoryId, long itemId) {
        boolean hasServices = tax.getService() == null || tax.getService().size() == 0 || tax.getService().contains(String.valueOf(service));
        boolean hasCategories = tax.getCategory() == null || tax.getCategory().size() == 0 || tax.getCategory().contains(String.valueOf(categoryId));
        boolean hasProducts = tax.getProduct() == null || tax.getProduct().size() == 0 || tax.getProduct().contains(String.valueOf(itemId));

        return hasServices && hasCategories && hasProducts;
    }

    /**
     * Calculate total tax applied from tax list
     *
     * @param taxes
     * @return
     */
    public static double aggregateTax(List<Taxation> taxes) {
        double totalTax = 0;

        for (Taxation tax : taxes) {
            try {
                if (!tax.isInclusiveType()) {
                    tax.setTaxAmount(Utils.round(tax.getTaxAmount(), 2, tax.getRoundingOption()));
                }
                totalTax += tax.getTaxAmount();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return totalTax;
    }

    /**
     * Calculate tax based on tax rate (Fixed / Percentage)
     *
     * @param tax
     * @param totalAmount
     * @param quantity
     * @param isOrderTax
     * @return
     */
    public static double applyTax(Taxation tax, double totalAmount, int quantity, boolean isOrderTax) {
        double totalTax = 0;

        switch (tax.getTaxRateType().toUpperCase()) {
            case "PERCENTAGE":
                totalTax = totalAmount * (tax.getTax() / 100);
                break;
            case "FIXED":
                totalTax = isOrderTax ? tax.getTax() : tax.getTax() * quantity;
                break;
        }
        totalTax = Utils.round(totalTax, 2, tax.getRoundingOption());
        tax.setTaxAmount(tax.getTaxAmount() + totalTax);

        return totalTax;
    }

    /**
     * Method to calculate item base price for tax inclusive amount
     *
     * @param items   - List<OrderItem>
     * @param taxList - ArrayList<Taxation>
     * @return itemsList - List<OrderItem>
     */
    public static List<OrderItem> getBaseFromInclusiveTax(List<OrderItem> items, ArrayList<Taxation> taxList, long serviceId) {
        List<OrderItem> itemsList = new ArrayList<OrderItem>();
        for (OrderItem orderItem : items) {
            OrderItem item = getBaseFromInclusiveTax(orderItem, taxList, serviceId);
            itemsList.add(item);
        }
        return itemsList;
    }

    /**
     * Method to calculate item base price for tax inclusive amount
     *
     * @param item    - OrderItem
     * @param taxList - ArrayList<Taxation>
     * @return item - OrderItem
     */
    public static OrderItem getBaseFromInclusiveTax(OrderItem item, ArrayList<Taxation> taxList, long serviceId) {
        double totalAmount = item.getItemPrice();
        double basePrice = getBaseFromInclusiveTax(totalAmount, taxList, serviceId, item.getCategoryId(), item.getItemId());

        item.setItemPrice(basePrice);
        return item;
    }

    /**
     * Method to calculate item base price for tax inclusive amount
     *
     * @param price
     * @param taxList    ArrayList<Taxation>
     * @param serviceId
     * @param categoryId
     * @param itemId
     * @return
     */
    public static double getBaseFromInclusiveTax(double price, ArrayList<Taxation> taxList, long serviceId, long categoryId, long itemId) {
        double fixedTaxAmount = 0;
        double percentTax = 0;
        double basePrice = 0;

        for (Taxation tax : taxList) {
            if (isItemEligible(tax, serviceId, categoryId, itemId)
                    && tax.getType().equalsIgnoreCase("ITEMTAX") && tax.isInclusiveType()) {
                switch (tax.getTaxRateType().toUpperCase()) {
                    case "PERCENTAGE":
                        percentTax += tax.getTax();
                        break;
                    case "FIXED":
                        fixedTaxAmount += tax.getTax();
                        break;
                }
            }
        }

        price -= fixedTaxAmount;

        basePrice = (price * 100) / (100 + percentTax);

        return basePrice;
    }

}
