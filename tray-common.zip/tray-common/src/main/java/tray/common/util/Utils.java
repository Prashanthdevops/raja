package tray.common.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class Utils {
    // Rounding mechanism
    static final String UP5 = "5UP";
    static final String DOWN4 = "DOWN4";
    static final String ROUNDINGDOWN = "ROUNDINGDOWN";
    static final String ROUNDINGUP = "ROUNDINGUP";

    /**
     * Perform rounding mechanism
     * @param value
     * @param places
     * @param roundingMode
     * @return
     */
    public static double round(double value, int places, String roundingMode) {
        if (places < 0) throw new IllegalArgumentException();
        if (Double.isNaN(value)) {
            return 0;
        }

        RoundingMode mode = RoundingMode.HALF_UP;
        switch (roundingMode) {
            case UP5:
                mode = RoundingMode.HALF_UP;
                break;
            case DOWN4:
                mode = RoundingMode.HALF_DOWN;
                break;
            case ROUNDINGDOWN:
                mode = RoundingMode.DOWN;
                break;
            case ROUNDINGUP:
                mode = RoundingMode.UP;
                break;
        }
        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(places, mode);
        return bd.doubleValue();
    }
}
