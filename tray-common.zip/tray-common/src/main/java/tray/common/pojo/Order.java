package tray.common.pojo;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

public class Order  implements Serializable {
	private List<OrderItem> orderItems;

	public List<OrderItem> getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(List<OrderItem> orderItems) {
		this.orderItems = orderItems;
	}

}
