package tray.common;

import static org.junit.Assert.assertEquals;

import java.math.RoundingMode;

import org.junit.Test;

import tray.common.util.Utils;

public class UtilsTest {
	
	@Test(expected = IllegalArgumentException.class)
	public void utilsIllegalArgumentExceptionTest(){
		Utils.round(1.1, -1, RoundingMode.HALF_UP.toString());
	}
	
	@Test
	public void utilsRoundingModeHalfUp(){
		assertEquals(1.17,Utils.round(1.166, 2, RoundingMode.HALF_UP.toString()), 1e-5);
	}
	
	@Test
	public void utilsRoundingModeHalfDown(){
		assertEquals(1.16,Utils.round(1.164, 2, RoundingMode.HALF_DOWN.toString()), 1e-5);
	}
	
	@Test
	public void utilsRoundingModeUP(){
		assertEquals(1.17,Utils.round(1.166, 2, RoundingMode.UP.toString()), 1e-5);
	}
	
	@Test
	public void utilsRoundingModeDown(){
		assertEquals(1.16,Utils.round(1.164, 2, RoundingMode.DOWN.toString()), 1e-5);
	}
}
