package tray.common.enums;
/**
 * CalculationStrategy enum used for taxation
 * 
 * @author Saikrishna Yelisetty
 * @version 1.0
 */
public enum CalculationStrategy {
	ORDERLEVEL,
	ITEMLEVEL
}
