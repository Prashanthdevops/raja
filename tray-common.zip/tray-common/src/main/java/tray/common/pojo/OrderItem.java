package tray.common.pojo;

import java.io.Serializable;

public class OrderItem implements Serializable {
    private double itemPrice;// Base Price of item
    private double taxableAmount;// Partial or total amount of base eligible for tax
    private long itemId;// Id of product
    private String id;// Id of item generated when order placed (to identify identical items)
    private long categoryId;
    private int quantity;
    private double taxAmount;
    private double actualItemPrice; // Amount with inclusive tax and without any discount for 1 quantity
    private boolean isTaxApplied = false;
    private boolean isDiscount = false; // will be true if discount is applied to item
    private boolean isTaxInclusive = false;

    public double getItemPrice() {
        return itemPrice;
    }

    public void setItemPrice(double itemPrice) {
        this.itemPrice = itemPrice;
    }

    public double getTaxableAmount() {
        return taxableAmount;
    }

    public void setTaxableAmount(double taxableAmount) {
        this.taxableAmount = taxableAmount;
    }

    public long getCategoryId() {
        return categoryId;
    }

    public void setCategoryId(long categoryId) {
        this.categoryId = categoryId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public long getItemId() {
        return itemId;
    }

    public void setItemId(long itemId) {
        this.itemId = itemId;
    }

    public double getTaxAmount() {
        return taxAmount;
    }

    public void setTaxAmount(double taxAmount) {
        this.taxAmount = taxAmount;
    }
    
    public boolean isTaxApplied() {
        return isTaxApplied;
    }

    public void setTaxApplied(boolean taxApplied) {
        isTaxApplied = taxApplied;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public double getActualItemPrice() {
        return actualItemPrice;
    }

    public void setActualItemPrice(double actualItemPrice) {
        this.actualItemPrice = actualItemPrice;
    }

    public boolean isDiscount() {
        return isDiscount;
    }

    public void setDiscount(boolean discount) {
        isDiscount = discount;
    }

    public boolean isTaxInclusive() {
        return isTaxInclusive;
    }

    public void setTaxInclusive(boolean taxInclusive) {
        isTaxInclusive = taxInclusive;
    }
}
